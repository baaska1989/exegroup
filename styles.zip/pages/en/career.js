import React from 'react'

const career = () => {
  return (
    <div>career</div>
  )
}

export default career