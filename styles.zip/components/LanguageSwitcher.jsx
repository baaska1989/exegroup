export default function LanguageSwitcher() {
    return (
        <div>
            <select>
                <option value='en'>English</option>
                <option value='jp'>Japan</option>
            </select>
        </div>
    );
}