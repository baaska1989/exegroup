export default {
    // Menu
    home: 'ホーム',
    about: 'エクセについて',
    overseasProjects: '海外プロジェクト',
    domesticProjects: '国内プロジェクト',
    internship: 'インターンシップ・採用',
    contact: 'お問い合わせ',
    slider1: '全てのマーケットには',
    slider2: '最高の投資機会がある',
    aboutPage: {
        about: 'エクセについて',
        short_desc: '私ども、株式会社エクセは1991年8月6日に生まれました。/n それから20年、20世紀の最後の10年と21世紀の最初の10年の激動の中をブティックの投資事業会社として、時代の流れとともに前へ前へと進んでまいりました。'
    }
    };